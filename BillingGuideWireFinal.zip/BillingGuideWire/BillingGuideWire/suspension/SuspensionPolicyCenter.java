package com.fremap.policy.suspension;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class SuspensionPolicyCenter {

	private static WebDriver driver;

	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"src\\test\\resources\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Test
	public void suspensionPolicy() {

		driver.get("https://10.229.211.136/pc/");
		// https://verti-sit-it.mapfre.net/pc/PolicyCenter.do
		// https://10.229.211.136/pc/
		// https://10.229.211.136/pc/PolicyCenter.do
		// https://verti-sit-it.mapfre.net/pc/PolicyCenter.do
		// https://www.google.com/

		// Loggin with the rol of Agent, CSR, Underwriter, or Manager
		WebElement username = driver.findElement(By
				.id("Login:LoginScreen:LoginDV:username-inputEl"));
		username.sendKeys("su");

		WebElement password = driver.findElement(By
				.id("Login:LoginScreen:LoginDV:password-inputEl"));
		password.sendKeys("gw");

		WebElement login = driver.findElement(By
				.id("Login:LoginScreen:LoginDV:submit-btnInnerEl"));
		login.click();

		// Policy dropdown
		WebElement deployablePolicy = driver.findElement(By
				.id("TabBar:PolicyTab-btnWrap"));
		deployablePolicy.click();

		WebElement textboxSearchPolicy = driver.findElement(By
				.id("TabBar:PolicyTab:PolicyTab_PolicyRetrievalItem-inputEl"));
		textboxSearchPolicy.sendKeys("VRT000000001732586");// send a policy's
															// number

		WebElement lensButton = driver.findElement(By
				.id("TabBar:PolicyTab:PolicyTab_PolicyRetrievalItem_Button"));
		lensButton.click();

		WebElement summaryPage = driver.findElement(By
				.id("PolicyFile_Summary:Policy_SummaryScreen:0"));
		assertEquals("Summary", summaryPage.getText());

		// If the transaction is fraudulent
		WebElement notFraudulentButton = driver
				.findElement(By
						.id("PolicyFile_Summary:Policy_SummaryScreen:WarningsPanelSet_tb:NotMarkFraudulentJob-btnInnerEl"));
		notFraudulentButton.click();

		// Actions Suspension
		WebElement actionsButton = driver.findElement(By
				.id("PolicyFile:PolicyFileMenuActions-btnWrap"));
		actionsButton.click();
		// MAybe use a Select
		WebElement actionsSuspension = driver
				.findElement(By
						.id("PolicyFile:PolicyFileMenuActions:PolicyFileMenuActions_SuspendReactivate_Vrt:PolicyFileMenuActions_SuspendPolicy_Ext-itemEl"));
		actionsSuspension.click();

		WebElement effectiveDateSuspension = driver
				.findElement(By
						.id("StartSuspension_Vrt:StartSuspensionScreen:CancelPolicyDV:SuspensionDate_date-inputEl"));
		effectiveDateSuspension.sendKeys("07/11/2019");

		WebElement suspensionButton = driver
				.findElement(By
						.id("StartSuspension_Vrt:StartSuspensionScreen:NewSuspension-btnInnerEl"));
		suspensionButton.click();

		// It takes a lot of time charging, maybe nees a wait o thread sleep...

		WebElement confirmationPage = driver
				.findElement(By
						.id("Suspension_VrtWizard:SuspensionWizard_QuoteVrtScreen:ttlBar"));
		assertEquals("Confirmation", confirmationPage.getText());

		// Go to Risk Analysis
		WebElement riskAnalysis = driver.findElement(By.id("ext-element-7722"));
		riskAnalysis.click();

		// Checkboxes List of RiskAnalysis

		List<WebElement> checkboxes = driver.findElements(By
				.className("x-grid-checkcolumn"));
		for (WebElement check : checkboxes) {
			if (!check.isSelected()) {
				check.click();
			}
		}

		WebElement approveButtonSuspension = driver
				.findElement(By
						.id("Suspension_VrtWizard:Job_RiskAnalysisScreen:RiskAnalysisCV:RiskEvaluationPanelSet:Approve-btnInnerEl"));
		approveButtonSuspension.click();

		WebElement okayButton = driver.findElement(By
				.id("RiskApprovalDetailsPopup:Update-btnInnerEl"));
		okayButton.click();

		// Go to confirmation page
		WebElement confirmationSuspension = driver.findElement(By
				.id("ext-element-7858"));// xpath //*[@id="ext-element-7858"],
											// just in case
		confirmationSuspension.click();

		WebElement confirmation = driver
				.findElement(By
						.id("Suspension_VrtWizard:SuspensionWizard_QuoteVrtScreen:ttlBar"));
		assertEquals("Confirmation", confirmation.getText());

		// Suspend Now Button
		WebElement suspendNowButton = driver
				.findElement(By
						.id("Suspension_VrtWizard:SuspensionWizard_QuoteVrtScreen:JobWizardToolbarButtonSet:SuspendNow-btnInnerEl"));
		suspendNowButton.click();
		
		//ALERT:Are you sure you want to suspend this policy? 
		
		

		// Submission issued
		WebElement submissionIssued = driver.findElement(By
				.id("JobComplete:JobCompleteScreen:ttlBar"));
		assertEquals("Submission Issued", submissionIssued.getText());

		WebElement submissionNumber = driver
				.findElement(By
						.id("JobComplete:JobCompleteScreen:JobCompleteDV:ViewJob-inputEl"));
		submissionNumber.isEnabled();

		WebElement policyNumber = driver
				.findElement(By
						.id("JobComplete:JobCompleteScreen:JobCompleteDV:ViewPolicy-inputEl"));
		policyNumber.isEnabled();
	}

	@AfterClass
	public static void tearDown() {

		// driver.close();
		// driver.quit();
	}

}