package com.fremap.billing.tickets;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;

import com.fremap.prueba.excel.ReadExcel;

/**
 * Test ID : 8390 - VWI-17244-CP211-SIT_Delinquency_200003_TC2_Create trouble tickets, Account tab 
 * @author CMONTE5
 *
 */  
public class CreateAccountTroubleTicketTest {
	private static WebDriver driver;
	private static ReadExcel readFile;
		
	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver","src\\test\\resources\\drivers\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--verbose");
        options.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
       
        driver = new ChromeDriver(options);
		readFile = new ReadExcel();
	}
		
	@Test
	public void createTroubleTickets() throws InterruptedException, IOException {
		
		String filepath = "src\\test\\resources\\excel\\BankTransferBilling.xlsx";
		
		
		Actions build = new Actions(driver);
		
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://10.231.193.245/bc/BillingCenter.do");

		//Login
		WebElement username = driver.findElement(By.id("Login:LoginScreen:LoginDV:username-inputEl"));
		username.sendKeys("su");

		WebElement password = driver.findElement(By.id("Login:LoginScreen:LoginDV:password-inputEl"));
		password.sendKeys("gw");

		WebElement login = driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl"));
		login.click();
		Thread.sleep(2000);
		
		String accountNumber = "0976565324";
		
		// Account arrow
		build.moveToElement(driver.findElement(By.xpath("//span[contains(@id, 'TabBar:AccountsTab-btnWrap')]"))).moveByOffset(30, 0).click().build().perform();
		// Textbox SearchAccount
		build.moveToElement(driver.findElement(By.xpath("//input[contains(@id, 'TabBar:AccountsTab:AccountNumberSearchItem-inputEl')]"))).moveByOffset(30, 0).click().sendKeys(accountNumber).build().perform();
		// Lens button
		WebElement searchButton = driver.findElement(By.id("TabBar:AccountsTab:AccountNumberSearchItem_Button"));
		searchButton.click();
		Thread.sleep(2000);
		
        //Click on My Trouble Tickets page
        By tickets = By.id("AccountGroup:MenuLinks:AccountGroup_AccountDetailTroubleTickets");
        buildClick(tickets);
        Thread.sleep(2000);
        
        //New Button
        WebElement newTicket = driver.findElement(By.xpath("//span[contains(@id, 'NewTroubleTicket-btnInnerEl')]"));
        newTicket.click();
        
        //fill all required fields
    	String TypeTroubleText = readFile.getCellValue(filepath, "Sheet7", 1, 1);
		String subjectText = readFile.getCellValue(filepath, "Sheet7", 2, 1);
		String detailsText = readFile.getCellValue(filepath, "Sheet7", 3, 1);
		String priorityText = readFile.getCellValue(filepath, "Sheet7", 4, 1);
        
		By typeTrouble = By.xpath("//input[contains(@id, 'TicketType')]");
        writeTextBoxByKeys(typeTrouble, TypeTroubleText);
        
        By subject = By.xpath("//input[contains(@id, 'Subject')]");
        writeTextBoxByKeys(subject, subjectText);
        
        By details = By.xpath("//textarea[contains(@id, 'DetailedDescription')]");
        writeTextBoxByKeys(details, detailsText);
        
        By priority = By.xpath("//input[contains(@id, 'Priority')]");
        writeTextBoxByKeys(priority, priorityText);
        
        By dueDateCalendar = By.xpath("//div[contains(@id, 'DueDate-trigger-picker')]");
        driver.findElement(dueDateCalendar).click();
        By dueDate = By.xpath("//input[contains(@id, 'DueDate-inputEl')]");
        driver.findElement(dueDate).sendKeys(Keys.SPACE,Keys.TAB,Keys.ENTER);
        

        By escalationDate = By.xpath("//input[contains(@id, 'EscalationDate-inputEl')]");
        driver.findElement(escalationDate).sendKeys(Keys.SPACE,Keys.TAB);
        
        By nextButton = By.xpath("//span[contains(@id, 'Next')]");
		buildClick(nextButton);
		Thread.sleep(2000);
		
		//Add Accounts/ Policies/ Policy Periods/ Producers as required 
		String numberAccount = readFile.getCellValue(filepath, "Sheet7", 7, 1);
		
		//Add Account
		By addAccounts = By.id("CreateTroubleTicketWizard:CreateTroubleTicketEntitiesScreen:TroubleTicketRelatedEntitiesDV:TroubleTicketRelatedEntitiesLV_tb:TroubleTicketRelatedEntitiesDV_AddAccountsButton-btnInnerEl");
		buildArrowClick(addAccounts);
		
		By accountSearch = By.xpath("//input[contains(@id, 'AccountNumberCriterion')]");
        writeTextBoxByKeys(accountSearch, numberAccount);
        
		By checkAccount = By.xpath("//img[contains(@class,'x-grid-checkcolumn ')]");
		driver.findElement(checkAccount).click();
		
		By addSelectedAccount = By.xpath("//span[contains(@id, 'addbutton')]");
		WebElement addSelectedAccountButton = driver.findElement(addSelectedAccount);
		addSelectedAccountButton.click();
		
		
	    
	    
	}
	public static void buildArrowClick(By locator){
		Actions build = new Actions(driver);
	    build.moveToElement(driver.findElement(locator)).moveByOffset(30, 0).click().build().perform();
		}
	
	public static void buildClick(By locator){
	Actions build = new Actions(driver);
    build.moveToElement(driver.findElement(locator)).moveByOffset(0, 0).click().build().perform();
	}
	public static void writeTextBoxByKeys(By locator, String excelText)
			throws InterruptedException {
		try {
			Thread.sleep(1000);
			driver.findElement(locator).sendKeys(Keys.CONTROL + "a");
			driver.findElement(locator).sendKeys(Keys.BACK_SPACE);
			driver.findElement(locator).sendKeys(excelText);
			Thread.sleep(2000);
			driver.findElement(locator).sendKeys(Keys.TAB);
			Thread.sleep(1000);

		} catch (Exception e) {
			System.out.println("Not found: " + locator);
		}
	}
}
