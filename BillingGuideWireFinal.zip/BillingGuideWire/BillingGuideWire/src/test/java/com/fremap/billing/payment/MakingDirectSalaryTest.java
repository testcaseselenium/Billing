package com.fremap.billing.payment;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;

import com.fremap.prueba.excel.ReadExcel;

/**
 *Test ID�:�8124�-�VWI-17041_CP001_Delinquency Process, policy
 * 
 * @author CMONTE5
 *
 */
public class MakingDirectSalaryTest {
	private static WebDriver driver;
	private static ReadExcel readFile;
		
	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver","src\\test\\resources\\drivers\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--verbose");
        options.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
       
        driver = new ChromeDriver(options);
		readFile = new ReadExcel();
	}
		
	@Test
	public void accountCharges() throws InterruptedException, IOException {
		String filepath = "src\\test\\resources\\excel\\BankTransferBilling.xlsx";
		
		
		Actions build = new Actions(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://10.229.211.136/bc/BillingCenter.do");
		
		//Login
		WebElement username = driver.findElement(By.id("Login:LoginScreen:LoginDV:username-inputEl"));
		username.sendKeys("su");

		WebElement password = driver.findElement(By.id("Login:LoginScreen:LoginDV:password-inputEl"));
		password.sendKeys("gw");

		WebElement login = driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl"));
		login.click();
		
		Thread.sleep(2000);
		
		String accountNumber = "0797008606";
		
		Thread.sleep(2000);
		// Account arrow
		build.moveToElement(driver.findElement(By.xpath("//span[contains(@id, 'TabBar:AccountsTab-btnWrap')]"))).moveByOffset(30, 0).click().build().perform();
        //Textbox SearchAccount
		build.moveToElement(driver.findElement(By.xpath("//input[contains(@id, 'TabBar:AccountsTab:AccountNumberSearchItem-inputEl')]"))).moveByOffset(30, 0).click().sendKeys(accountNumber).build().perform();//Account RenewalTest

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// Lens button
		WebElement searchButton = driver.findElement(By.id("TabBar:AccountsTab:AccountNumberSearchItem_Button"));
		searchButton.click();
        Thread.sleep(2000);
        
        WebElement actions = driver.findElement(By.id("AccountGroup:AccountDetailMenuActions-btnEl"));
		actions.click();
		
		WebElement newPayment = driver.findElement(By.id("AccountGroup:AccountDetailMenuActions:AccountDetailMenuActions_Payments-textEl"));
		newPayment.click();
		
		WebElement newBillPayment = driver.findElement(By.id("AccountGroup:AccountDetailMenuActions:AccountDetailMenuActions_Payments:AccountDetailMenuActions_NewDirectBillPayment-textEl"));
		newBillPayment.click();
		
		WebElement overrideDistribution = driver.findElement(By.id("NewDirectBillPayment:EditDBPaymentScreen:OverrideModeButton-btnInnerEl"));
		overrideDistribution.click();
		
		WebElement addItems = driver.findElement(By.xpath("//span[contains(@id, 'AddItems-btnInnerEl')]"));
		js.executeScript("arguments[0].scrollIntoView();", addItems);
		addItems.click();
		
		//Search Payment Invoice
		By searchLocator = By.xpath("//a[contains(@id, 'SearchAndResetInputSet:SearchLinksInputSet:Search')]");
		buildClick(searchLocator);

		By netAmount = By.xpath("//div[contains(text(), 'Billed')]/../../..//td[10]");
		WebElement netAmountElement = driver.findElement(netAmount);
		String netAmountNumber = netAmountElement.getText();
		System.out.println(netAmountNumber);
		
		By checkItem = By.xpath("//div[contains(text(), 'Billed')]/../../..//img[contains(@class, 'checkcolumn')]");
		driver.findElement(checkItem).click();
		
		By selectInvoiceItems = By.id("DirectBillAddInvoiceItemsPopup:SelectInvoiceItems-btnInnerEl");
		WebElement selectInvoiceElement = driver.findElement(selectInvoiceItems);
		js.executeScript("arguments[0].scrollIntoView();", selectInvoiceElement);
		selectInvoiceElement.click();
		
		By ammountLocator = By.xpath("//a[contains(@class, 'gw-currency')]");
		WebElement ammountElement = driver.findElement(ammountLocator);
		js.executeScript("arguments[0].scrollIntoView();", ammountElement);
		String ammountNumber = ammountElement.getText();
        System.out.println(ammountNumber);
		
		By realDateBox = By.id("NewDirectBillPayment:EditDBPaymentScreen:PaymentDetailsDV:RealPaymentDate-inputEl");
		driver.findElement(realDateBox).sendKeys("12/12/2019");
		
		By ammountBox = By.id("NewDirectBillPayment:EditDBPaymentScreen:PaymentDetailsDV:Amount-inputEl");
		writeTextBoxByKeys(ammountBox, ammountNumber);
		driver.findElement(ammountBox).sendKeys(Keys.BACK_SPACE);
		
		//PAYMENT TYPE
		By newPaymentLink = By.id("NewDirectBillPayment:EditDBPaymentScreen:PaymentDetailsDV:PaymentInstrument:CreateNewPaymentInstrument");
		WebElement newPaymentElement = driver.findElement(newPaymentLink);
		js.executeScript("arguments[0].scrollIntoView();", newPaymentElement);
		newPaymentElement.click();
		
		//PAYMENT SCREEN
		String paymentMethodText = readFile.getCellValue(filepath, "Sheet5", 0, 1);
		
		By paymentMethod = By.id("NewPaymentInstrumentInflow_VrtPopup:PaymentMethod-inputEl");
		writeTextBoxByKeys(paymentMethod, paymentMethodText);
		
		By updateOK = By.xpath("//span[contains(@id, 'Update')]");
		driver.findElement(updateOK).click();
		
//		//Execute and Verify
		By executeButton = By.id("NewDirectBillPayment:EditDBPaymentScreen:Update-btnEl");
		WebElement executeButtonElement = driver.findElement(executeButton);
		js.executeScript("arguments[0].scrollIntoView();", executeButtonElement);
		executeButtonElement.click();
		Thread.sleep(2000);
		
		By paymentAvailable = By.xpath("//span[contains(text(),'Payment')]");
		build.moveToElement(driver.findElement(paymentAvailable)).moveByOffset(0, 0).click().build().perform();//Account RenewalTest
       
		By confirmAmmount = By.xpath("//div[contains(text(),'"+ netAmountNumber +"')]");
		WebElement ammountPayment = driver.findElement(confirmAmmount);
		js.executeScript("arguments[0].scrollIntoView();", ammountPayment);
		System.out.println(ammountPayment.getText());
		assertTrue(ammountPayment.isEnabled());
	}
	
	public static void buildClick(By locator){
	Actions build = new Actions(driver);
    build.moveToElement(driver.findElement(locator)).moveByOffset(0, 0).click().build().perform();
	}
	
	public static void writeTextBoxByKeys(By locator, String excelText)
			throws InterruptedException {
		try {
			Thread.sleep(1000);
			driver.findElement(locator).sendKeys(Keys.CONTROL + "a");
			driver.findElement(locator).sendKeys(Keys.BACK_SPACE);
			driver.findElement(locator).sendKeys(excelText);
			driver.findElement(locator).sendKeys(Keys.ENTER);
			Thread.sleep(2000);
			driver.findElement(locator).sendKeys(Keys.TAB);
			Thread.sleep(1000);

		} catch (Exception e) {
			System.out.println("Not found: " + locator);
		}
	}
}
