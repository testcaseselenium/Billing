package com.fremap.billing.tickets;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;

import com.fremap.prueba.excel.ReadExcel;

/**
 * Test ID : 8389 - VWI-17244-CP210-SIT_Delinquency_200003_TC1_Create trouble tickets, Desktop tab
 * @author CMONTE5
 *
 */
public class CreateDesktopTroubleTicketsTest {
	private static WebDriver driver;
	private static ReadExcel readFile;
		
	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver","src\\test\\resources\\drivers\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--verbose");
        options.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
       
        driver = new ChromeDriver(options);
		readFile = new ReadExcel();
	}
		
	@Test
	public void createTroubleTickets() throws InterruptedException, IOException {
		
		String filepath = "src\\test\\resources\\excel\\BankTransferBilling.xlsx";
		
		Actions build = new Actions(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://10.229.211.136/bc/BillingCenter.do");

		//Login
		WebElement username = driver.findElement(By.id("Login:LoginScreen:LoginDV:username-inputEl"));
		username.sendKeys("su");

		WebElement password = driver.findElement(By.id("Login:LoginScreen:LoginDV:password-inputEl"));
		password.sendKeys("gw");

		WebElement login = driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl"));
		login.click();
		Thread.sleep(2000);
		
		//Navigate to Desktop
		build.moveToElement(driver.findElement(By.id("TabBar:DesktopTab"))).moveByOffset(0, 0).click().click().build().perform();
        
        //Click on My Trouble Tickets page
        By tickets = By.id("DesktopGroup:MenuLinks:DesktopGroup_DesktopTroubleTickets");
        build.moveToElement(driver.findElement(tickets)).moveByOffset(0, 0).click().build().perform();
        Thread.sleep(2000);
        
        //New Button
        WebElement newTicket = driver.findElement(By.xpath("//span[contains(@id, 'NewTroubleTicket-btnInnerEl')]"));
        newTicket.click();
        
        //fill all required fields
    	String TypeTroubleText = readFile.getCellValue(filepath, "Sheet7", 1, 1);
		String subjectText = readFile.getCellValue(filepath, "Sheet7", 2, 1);
		String detailsText = readFile.getCellValue(filepath, "Sheet7", 3, 1);
		String priorityText = readFile.getCellValue(filepath, "Sheet7", 4, 1);
        
		By typeTrouble = By.xpath("//input[contains(@id, 'TicketType')]");
        writeTextBoxByKeys(typeTrouble, TypeTroubleText);
        
        By subject = By.xpath("//input[contains(@id, 'Subject')]");
        writeTextBoxByKeys(subject, subjectText);
        
        By details = By.xpath("//textarea[contains(@id, 'DetailedDescription')]");
        writeTextBoxByKeys(details, detailsText);
        
        By priority = By.xpath("//input[contains(@id, 'Priority')]");
        writeTextBoxByKeys(priority, priorityText);
        
        By dueDateCalendar = By.xpath("//div[contains(@id, 'DueDate-trigger-picker')]");
        driver.findElement(dueDateCalendar).click();
        By dueDate = By.xpath("//input[contains(@id, 'DueDate-inputEl')]");
        driver.findElement(dueDate).sendKeys(Keys.SPACE,Keys.TAB,Keys.ENTER);
        
//        By escalationDateCalendar = By.xpath("//div[contains(@id, 'EscalationDate-trigger-picker')]");
//        driver.findElement(escalationDateCalendar).click();
//        By escalationDate = By.xpath("//input[contains(@id, 'EscalationDate-inputEl')]");
//        driver.findElement(escalationDate).sendKeys(Keys.SPACE,Keys.TAB);
        
        By nextButton = By.xpath("//span[contains(@id, 'Next')]");
		buildClick(nextButton);
		Thread.sleep(3000);
		
		//Add Account
		By addAccounts = By.xpath("//span[contains(@id, 'AddAccountsButton-btnInnerEl')]");
		WebElement accountElement = driver.findElement(addAccounts);
		js.executeScript("arguments[0].scrollIntoView();", accountElement);
		accountElement.click();
//		buildClick(addAccounts);
		
		String numberAccount = readFile.getCellValue(filepath, "Sheet6", 7, 1);
		By accountSearch = By.xpath("//input[contains(@id, 'AccountNumberCriterion')]");
        writeTextBoxByKeys(accountSearch, numberAccount);
        
		By checkAccount = By.xpath("//img[contains(@class,'x-grid-checkcolumn ')]");
		driver.findElement(checkAccount).click();
		
		By addSelectedAccount = By.xpath("//span[contains(@id, 'addbutton')]");
		WebElement addSelectedAccountButton = driver.findElement(addSelectedAccount);
		addSelectedAccountButton.click();
		
		//Add Policy
		By addPolicy = By.xpath("//span[contains(@id, 'AddPoliciesButton')]");
		WebElement addPolicyButton = driver.findElement(addPolicy);
		addPolicyButton.click();

		String numberPolicy = readFile.getCellValue(filepath, "Sheet6", 8, 1);
		By policySearch = By.xpath("//input[contains(@id, 'PolicyNumberCriterion')]");
        writeTextBoxByKeys(policySearch, numberPolicy);
        
		By checkPolicy = By.xpath("//img[contains(@class,'x-grid-checkcolumn ')]");
		driver.findElement(checkPolicy).click();
		
		WebElement addSelectedPolicyButton = driver.findElement(addSelectedAccount);
		addSelectedPolicyButton.click();
		
		//Add PolicyPeriods
		By addPolicyPeriods = By.xpath("//span[contains(@id, 'AddPolicyPeriodsButton')]");
		WebElement addPolicyPeriodsButton = driver.findElement(addPolicyPeriods);
		addPolicyPeriodsButton.click();

		writeTextBoxByKeys(policySearch, numberPolicy);

		driver.findElement(checkPolicy).click();

		WebElement addSelectedPeriodButton = driver.findElement(addSelectedAccount);
		addSelectedPeriodButton.click();
		
		//Add Company
		By addProducers = By.xpath("//span[contains(@id, 'AddProducersButton')]");
		WebElement addProducersButton = driver.findElement(addProducers);
		addProducersButton.click();

		String producerText = readFile.getCellValue(filepath, "Sheet7", 9, 1);
		By producerName = By.xpath("//input[contains(@id, 'ProducerNameCriterion')]");
		writeTextBoxByKeys(producerName, producerText);

		driver.findElement(checkPolicy).click();

		WebElement addSelectedProducersButton = driver.findElement(addSelectedAccount);
		addSelectedProducersButton.click();
		
		WebElement nextElemento = driver.findElement(nextButton);
		nextElemento.click();
		Thread.sleep(3000);
		
		By holdType = By.xpath("//input[contains(@id, '0:HoldType')]");
		driver.findElement(holdType).click();
		
		String releaseDateText = readFile.getCellValue(filepath, "Sheet7", 10, 1);
			
		By releaseDate = By.xpath("//input[contains(@id, 'ReleaseDate')]");
	    writeTextBoxByKeys(releaseDate, releaseDateText);
		
		By addButton = By.id("CreateTroubleTicketWizard:CreateTroubleTicketTransactionsScreen:TroubleTicketRelatedTransactionsDV:TroubleTicketTransactionsLV_tb:TroubleTicketRelatedTransactionsDV_AddButton-btnInnerEl");
		WebElement addButtonButton = driver.findElement(addButton);
		js.executeScript("arguments[0].scrollIntoView();", addButtonButton);
		addButtonButton.click();
		Thread.sleep(2000);
		
		driver.findElement(checkPolicy).click();
		
		By selectButton = By.xpath("//span[contains(@id, 'Select')]");
		WebElement selectButtonButton = driver.findElement(selectButton);
		selectButtonButton.click();
		
		WebElement nextElement2 = driver.findElement(nextButton);
		nextElement2.click();
		Thread.sleep(3000);
		
		String assignmentText = readFile.getCellValue(filepath, "Sheet7", 11, 1);
		
		By assignment = By.xpath("//input[contains(@id, 'AssignTicketOwner')]");
	    writeTextBoxByKeys(assignment, assignmentText);
		
		By lens = By.xpath("//a[contains(@id, 'AssignTicketOwner_PickerButton')]");
		WebElement lensElement = driver.findElement(lens);
		js.executeScript("arguments[0].scrollIntoView();", lensElement);
		lensElement.click();
		
		//Search by Group
		String typeAssignmentText = readFile.getCellValue(filepath, "Sheet7", 12, 1);
		String nameAssignmentText = readFile.getCellValue(filepath, "Sheet7", 13, 1);
	
		By typeAssignment = By.xpath("//input[contains(@id, 'SearchFor-inputEl')]");
	    writeTextBoxByKeys(typeAssignment, typeAssignmentText);
		
	    By nameAssignment = By.xpath("//input[contains(@id, 'GroupCriteriaName-inputEl')]");
	    writeTextBoxByKeys(nameAssignment, nameAssignmentText);
	    
	    By assignButton = By.xpath("//a[contains(@id, ':0:_Select')]");
	    WebElement assignButtonElement = driver.findElement(assignButton);
		js.executeScript("arguments[0].scrollIntoView();", assignButtonElement);
		assignButtonElement.click();
	    
	    By finishButton = By.xpath("//span[contains(@id, 'Finish')]");
	    WebElement finishButtonButton = driver.findElement(finishButton);
	    finishButtonButton.click();
	    
	    
	}
	public static void buildClick(By locator){
	Actions build = new Actions(driver);
    build.moveToElement(driver.findElement(locator)).moveByOffset(0, 0).click().build().perform();
	}
	public static void writeTextBoxByKeys(By locator, String excelText)
			throws InterruptedException {
		try {
			Thread.sleep(1000);
			driver.findElement(locator).sendKeys(Keys.CONTROL + "a");
			driver.findElement(locator).sendKeys(Keys.BACK_SPACE);
			driver.findElement(locator).sendKeys(excelText);
			driver.findElement(locator).sendKeys(Keys.ENTER);
			Thread.sleep(2000);
			driver.findElement(locator).sendKeys(Keys.TAB);
			Thread.sleep(1000);

		} catch (Exception e) {
			System.out.println("Not found: " + locator);
		}
	}
}
