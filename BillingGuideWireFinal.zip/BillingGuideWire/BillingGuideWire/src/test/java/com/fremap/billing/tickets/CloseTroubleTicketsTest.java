package com.fremap.billing.tickets;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;

/**
 * Test ID : 8391 - VWI-17244-CP212-SIT_Delinquency_200003_TC6_Close Trouble Tickets
 * @author CMONTE5
 *
 */
public class CloseTroubleTicketsTest {
	private static WebDriver driver;
	
		
	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver","src\\test\\resources\\drivers\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--verbose");
        options.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
       
        driver = new ChromeDriver(options);
	}
		
	@Test
	public void closeTroubleTickets() throws InterruptedException, IOException {
		Actions build = new Actions(driver);

		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://10.229.211.136/bc/BillingCenter.do");

		//Login
		WebElement username = driver.findElement(By.id("Login:LoginScreen:LoginDV:username-inputEl"));
		username.sendKeys("su");

		WebElement password = driver.findElement(By.id("Login:LoginScreen:LoginDV:password-inputEl"));
		password.sendKeys("gw");

		WebElement login = driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl"));
		login.click();
		
		Thread.sleep(2000);
		
		//Navigate to Desktop
		build.moveToElement(driver.findElement(By.id("TabBar:DesktopTab"))).moveByOffset(0, 0).click().click().build().perform();
        
        //Click on My Trouble Tickets page
        By tickets = By.id("DesktopGroup:MenuLinks:DesktopGroup_DesktopTroubleTickets");
        build.moveToElement(driver.findElement(tickets)).moveByOffset(0, 0).click().build().perform();
        Thread.sleep(2000);
        
        try {
	
       //Select all trouble tickets required 
        @SuppressWarnings("unused")
		boolean correct = false;
		List<WebElement> checkboxes = driver.findElements(By.tagName("img"));
		Thread.sleep(2000);
		for (WebElement eachInput : checkboxes) {
			if (!eachInput.isSelected() && "x-grid-checkcolumn ".equals(eachInput.getAttribute("class"))) {
				eachInput.click();
				correct = true;
			} else {
				correct = false;
			}
		}
		
		//Click Close button
		WebElement close = driver.findElement(By.xpath("//span[contains(@id, 'DesktopTroubleTickets_CloseButton-btnInnerEl')]"));
		close.click();
		
		WebElement ok = driver.findElement(By.id("button-1005-btnInnerEl"));
		ok.click();
		
		} catch (Exception e) {
			System.out.println("There aren't trouble tickets availables");
		}
	}
}
