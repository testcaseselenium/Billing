package com.fremap.billing.integrate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;

/**
 * Test ID : 8405 - VWI-17244-CP184-SIT_BCLOCALIZATION_200001_TC1_Language validation for Administration option_TC1_Language validation for Administration option 
 * @author CMONTE5
 *
 */
public class LanguageAdministrationTest {
	private static WebDriver driver;
		
	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver","src\\test\\resources\\drivers\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--verbose");
        options.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
       
        driver = new ChromeDriver(options);
	}
		
	@Test
	public void accountCharges() throws InterruptedException, IOException {
		Actions build = new Actions(driver);

		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://10.229.211.136/bc/BillingCenter.do");

		//Login
		WebElement username = driver.findElement(By.id("Login:LoginScreen:LoginDV:username-inputEl"));
		username.sendKeys("su");

		WebElement password = driver.findElement(By.id("Login:LoginScreen:LoginDV:password-inputEl"));
		password.sendKeys("gw");

		WebElement login = driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl"));
		login.click();
		
		Thread.sleep(2000);
		// Press the "Gear" icon
		build.moveToElement(driver.findElement(By.xpath("//span[contains(@id, 'TabLinkMenuButton-btnEl')]"))).moveByOffset(0, 0).click().build().perform();
		// Select "International" option
		build.moveToElement(driver.findElement(By.xpath("//span[contains(@id, 'TabBar:LanguageTabBarLink-textEl')]"))).moveByOffset(0, 0).click().build().perform();
		// Select "Language" option
		build.moveToElement(driver.findElement(By.xpath("//span[contains(@id, 'TabBar:LanguageTabBarLink:languageSwitcher-textEl')]"))).moveByOffset(0, 0).click().build().perform();
		// Select "Italiano" option
		build.moveToElement(driver.findElement(By.xpath("//span[contains(@id, 'TabBar:LanguageTabBarLink:languageSwitcher:3:langs-textEl')]"))).moveByOffset(0, 0).click().build().perform();
	       
		Thread.sleep(2000);
		
		// From the home page select the tab "Administration"and "Business Setting" and "Billing Plans" and "Verti Italy Billing Plan"
		build.moveToElement(driver.findElement(By.id("TabBar:AdministrationTab-btnWrap"))).moveByOffset(0, 0).click().build().perform();
		build.moveToElement(driver.findElement(By.id("Admin:MenuLinks:Admin_BusinessSettings"))).moveByOffset(0, 0).click().build().perform();
		Thread.sleep(2000);
		build.moveToElement(driver.findElement(By.id("Admin:MenuLinks:Admin_BusinessSettings:BusinessSettings_BillingPlans"))).moveByOffset(0, 0).click().build().perform();
	    Thread.sleep(2000);
		//Verti Italy Payment Plan
		By vertItaly = By.xpath("//div[@class = 'x-grid-cell-inner ']/../../../../..//table[1]//td[2]/div");
		driver.findElement(vertItaly).click();
		
		//System shows: "Versamento"  translate with "Rimborso","Versamenti" translate with "Rimborsi " & "Valuta" translate with "Divisa" 
		WebElement currency = driver.findElement(By.xpath("//label[contains(@id, 'Currency')]"));
		WebElement payment = driver.findElement(By.xpath("//label[contains(@id, 'BillingPlanDetailDV:PaymentDueDayLogic')]"));
		WebElement repayment = driver.findElement(By.xpath("//label[contains(@id, 'BillingPlanDetailDV:DisbursementAmount')]"));
        assertTrue(currency.isEnabled());
        assertEquals(currency.getText(), "Divisa");
        assertEquals(payment.getText(), "Fissa data di scadenza pagamento il giorno");//Pagamento, versamenti
        assertEquals(repayment.getText(), "Rivedi Rimborsi superiori a");//Rimborsi
	}
	
	public static void writeTextBoxByKeys(By locator, String excelText)
			throws InterruptedException {
		try {
			Thread.sleep(1000);
			driver.findElement(locator).sendKeys(Keys.CONTROL + "a");
			driver.findElement(locator).sendKeys(Keys.BACK_SPACE);
			driver.findElement(locator).sendKeys(excelText);
			Thread.sleep(1000);
			driver.findElement(locator).sendKeys(Keys.ENTER);
			Thread.sleep(2000);
			driver.findElement(locator).sendKeys(Keys.TAB);
			Thread.sleep(1000);

		} catch (Exception e) {
			System.out.println("Not found: " + locator);
		}
}
}