package com.fremap.billing.delincuency.batches;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;

/**
 * Test ID�:�8125�-�VWI-17040_CP001_Check how delinquency affects policy change
 * @author CMONTE5
 *
 */
public class DelincuencyPolicyChangeTest {
	private static WebDriver driver;
	
		
	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver","src\\test\\resources\\drivers\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--verbose");
        options.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
       
        driver = new ChromeDriver(options);
	}
		
	@Test
	public void delincuencyPolicyChange() throws InterruptedException, IOException {
		Actions build = new Actions(driver);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://10.231.193.245/bc/BillingCenter.do");

		//Login
		WebElement username = driver.findElement(By.id("Login:LoginScreen:LoginDV:username-inputEl"));
		username.sendKeys("su");

		WebElement password = driver.findElement(By.id("Login:LoginScreen:LoginDV:password-inputEl"));
		password.sendKeys("gw");

		WebElement login = driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl"));
		login.click();
		
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		Thread.sleep(2000);
		
		// ADMINISTRATION
		
		//Billing Plans
		build.moveToElement(driver.findElement(By.xpath("//span[contains(@id, 'TabBar:AdministrationTab-btnWrap')]"))).moveByOffset(0, 0).click().build().perform();
		build.moveToElement(driver.findElement(By.id("Admin:MenuLinks:Admin_BusinessSettings"))).click().build().perform();
		Thread.sleep(2000);
		build.moveToElement(driver.findElement(By.id("Admin:MenuLinks:Admin_BusinessSettings:BusinessSettings_BillingPlans"))).click().build().perform();
		Thread.sleep(2000);
		
		//Assert Verti Italy Billing Plan
		By vertiItalyBilling = By.xpath("//div[@class = 'x-grid-cell-inner ']/../../../../..//table[1]//td[2]/div/a");
		
		WebElement billingPlanElement = driver.findElement(vertiItalyBilling);
		billingPlanElement.click();
		
		WebElement planScreen = driver.findElement(By.xpath("//div[contains(@id,'PlanDetailDV:Name-inputEl')]"));
		assertTrue(planScreen.isEnabled());
		System.out.println(planScreen.getText());
		
		//Delinquency Plans Verti Italy Delinquency Plan
		build.moveToElement(driver.findElement(By.id("Admin:MenuLinks:Admin_BusinessSettings:BusinessSettings_DelinquencyPlans"))).moveByOffset(30, 0).click().build().perform();//Account RenewalTest
	    WebElement vertiItalyDelinquencyPlanElement = driver.findElement(vertiItalyBilling);
	    vertiItalyDelinquencyPlanElement.click();

	    WebElement planScreenD = driver.findElement(By.xpath("//div[contains(@id,'PlanDetailDV:Name-inputEl')]"));
		assertTrue(planScreenD.isEnabled());
		System.out.println(planScreenD.getText());
	    
		//Payment Allocation Plans 
		By allocationPlans = By.id("Admin:MenuLinks:Admin_BusinessSettings:BusinessSettings_PaymentAllocationPlans");
		build.moveToElement(driver.findElement(allocationPlans)).moveByOffset(30, 0).click().build().perform();//Account RenewalTest
	    WebElement vertiItalyAllocationPlanElement = driver.findElement(vertiItalyBilling);
	    vertiItalyAllocationPlanElement.click();

	    WebElement planScreenA = driver.findElement(By.xpath("//div[contains(@id,'PlanDetailDV:Name-inputEl')]"));
		assertTrue(planScreenA.isEnabled());
		System.out.println(planScreenA.getText());
	}
	
	public static void billingPlans(By locator, By screen) throws InterruptedException{
		Actions build = new Actions(driver);
		build.moveToElement(driver.findElement(locator)).moveByOffset(0, 0).click().build().perform();
	    WebElement planElement = driver.findElement(locator);
	    planElement.click();
	    
	    WebElement planScreenD = driver.findElement(screen);
		assertTrue(planScreenD.isEnabled());
		System.out.println(planScreenD.getText());
		Thread.sleep(1000);
	}
	
}
