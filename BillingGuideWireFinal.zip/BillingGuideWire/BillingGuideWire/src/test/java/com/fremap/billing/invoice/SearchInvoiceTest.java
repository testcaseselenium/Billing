package com.fremap.billing.invoice;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;

import com.fremap.prueba.excel.ReadExcel;

/**
 * Test ID : 8361 - VWI-17244-CP203-SIT_Invoicing_200012_TC4_Viewing of Invoice Item details from Account Charges
 * @author CMONTE5
 *
 */
public class SearchInvoiceTest {
	private static WebDriver driver;
	private static ReadExcel readFile;
		
	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver","src\\test\\resources\\drivers\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--verbose");
        options.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
       
        driver = new ChromeDriver(options);
		readFile = new ReadExcel();
	}
		
	@Test
	public void accountCharges() throws InterruptedException, IOException {
		String filepath = "src\\test\\resources\\excel\\BankTransferBilling.xlsx";
		
		

		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://10.229.211.136/bc/BillingCenter.do");
		
		//Login
		WebElement username = driver.findElement(By.id("Login:LoginScreen:LoginDV:username-inputEl"));
		username.sendKeys("su");

		WebElement password = driver.findElement(By.id("Login:LoginScreen:LoginDV:password-inputEl"));
		password.sendKeys("gw");

		WebElement login = driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl"));
		login.click();
		Thread.sleep(2000);
		
		//Search by Account
		By searchTab = By.xpath("//span[contains(@id, 'TabBar:SearchTab-btnWrap')]");
		buildArrowClick(searchTab);
	
		By invoicesOption = By.id("TabBar:SearchTab:SearchGroup_InvoiceSearch-textEl");
		buildClick(invoicesOption); 
		Thread.sleep(2000);
        
		String accountNumber = readFile.getCellValue(filepath, "Sheet6", 7, 1);
        By accountNumberCriterion = By.xpath("//input[contains(@id,'AccountNumberCriterion-inputEl')]");
        writeTextBoxByKeys(accountNumberCriterion, accountNumber);
        Thread.sleep(2000);
        
        By searchButton = By.xpath("//a[contains(@id,'SearchAndResetInputSet:SearchLinksInputSet:Search')]");
        buildClick(searchButton);
        
        By invoiceNumber = By.xpath("//a[contains(text(), '"+ accountNumber +"')]/../../..//td[3]");
        WebElement invoiceNumberElement =driver.findElement(invoiceNumber);
        String invoiceNumberText = invoiceNumberElement.getText();
        System.out.println(invoiceNumberText);
        
      //Search by Invoice 
		buildArrowClick(searchTab);
		buildClick(invoicesOption);
		Thread.sleep(2000);


		By invoiceNumberCriterion = By.xpath("//input[contains(@id,'InvoiceNumberCriterion-inputEl')]");
		writeTextBoxByKeys(invoiceNumberCriterion, invoiceNumberText);
		
		buildClick(searchButton);
		WebElement invoiceElementAfter =driver.findElement(invoiceNumber);
		String invoiceTextAfter = invoiceNumberElement.getText();
        System.out.println(invoiceTextAfter);
        
		assertTrue(invoiceElementAfter.isEnabled());
		assertEquals(invoiceNumberText,invoiceTextAfter);
	}
	
	public static void buildArrowClick(By locator){
		Actions build = new Actions(driver);
	    build.moveToElement(driver.findElement(locator)).moveByOffset(30, 0).click().build().perform();
		}
	public static void buildClick(By locator){
		Actions build = new Actions(driver);
	    build.moveToElement(driver.findElement(locator)).moveByOffset(0, 0).click().build().perform();
		}
	public static void writeTextBoxByKeys(By locator, String excelText)
			throws InterruptedException {
		try {
			Thread.sleep(1000);
			driver.findElement(locator).sendKeys(Keys.CONTROL + "a");
			driver.findElement(locator).sendKeys(Keys.BACK_SPACE);
			driver.findElement(locator).sendKeys(excelText);
			driver.findElement(locator).sendKeys(Keys.TAB);
			Thread.sleep(1000);

		} catch (Exception e) {
			System.out.println("Not found: " + locator);
		}
}
}
