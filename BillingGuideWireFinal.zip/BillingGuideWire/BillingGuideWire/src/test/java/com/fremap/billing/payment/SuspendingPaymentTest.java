package com.fremap.billing.payment;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;

import com.fremap.prueba.excel.ReadExcel;

/**
 *Test ID�:�8124�-�VWI-17041_CP001_Delinquency Process, policy
 * 
 * @author CMONTE5
 *
 */
public class SuspendingPaymentTest {
	private static WebDriver driver;
	private static ReadExcel readFile;
		
	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver","src\\test\\resources\\drivers\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--verbose");
        options.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
       
        driver = new ChromeDriver(options);
		readFile = new ReadExcel();
	}
		
	@Test
	public void accountCharges() throws InterruptedException, IOException {
		String filepath = "src\\test\\resources\\excel\\BankTransferBilling.xlsx";
		Actions build = new Actions(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://10.229.211.136/bc/BillingCenter.do");
		
		//Login
		WebElement username = driver.findElement(By.id("Login:LoginScreen:LoginDV:username-inputEl"));
		username.sendKeys("su");

		WebElement password = driver.findElement(By.id("Login:LoginScreen:LoginDV:password-inputEl"));
		password.sendKeys("gw");

		WebElement login = driver.findElement(By.id("Login:LoginScreen:LoginDV:submit-btnInnerEl"));
		login.click();
		
		Thread.sleep(2000);
		
		build.moveToElement(driver.findElement(By.xpath("//span[contains(@id, 'TabBar:DesktopTab-btnWrap')]"))).moveByOffset(30, 0).click().build().perform();
		build.moveToElement(driver.findElement(By.xpath("//span[contains(@id, 'DesktopSuspensePayments-textEl')]"))).moveByOffset(0, 0).click().build().perform();
		build.moveToElement(driver.findElement(By.xpath("//span[contains(@id, 'NewPayment-btnInnerEl')]"))).moveByOffset(0, 0).click().build().perform();

		String creationDateText = readFile.getCellValue(filepath, "Sheet6", 1, 1);
		String ammountText = readFile.getCellValue(filepath, "Sheet6", 2, 1);
		String paymentInstrumentText = readFile.getCellValue(filepath, "Sheet6", 3, 1);
		String invoiceNumberText = readFile.getCellValue(filepath, "Sheet6", 4, 1);
		
		By creationDateBox = By.xpath("//input[contains(@id, 'paymentDate-inputEl')]");
		writeTextBoxByKeys(creationDateBox, creationDateText);
		
		By ammount = By.xpath("//input[contains(@id, 'amount-inputEl')]");
		writeTextBoxByKeys(ammount, ammountText);
		
		By paymentInstrument = By.xpath("//input[contains(@id, 'PaymentInstrument-inputEl')]");
		writeTextBoxByKeys(paymentInstrument, paymentInstrumentText);
		driver.findElement(paymentInstrument).click();
		
		By updateOK = By.xpath("//span[contains(@id, 'Update')]");
		driver.findElement(updateOK).click();
		
		//Edit
		By editButton = By.xpath("//a[contains(text(), 'Check')]/../../..//a[contains(text(),'Edit')]");
		WebElement editElement = driver.findElement(editButton);
		js.executeScript("arguments[0].scrollIntoView();", editElement);
        editElement.click();
        
		By invoiceNumber = By.xpath("//input[contains(@id, 'InvoiceNumber-inputEl')]");
		writeTextBoxByKeys(invoiceNumber, invoiceNumberText);
		driver.findElement(updateOK).click();
		
		//Apply
		By applyButton = By.xpath("//a[contains(text(), 'Check')]/../../..//a[contains(text(),'Apply')]");
		WebElement applyElement = driver.findElement(applyButton);
		js.executeScript("arguments[0].scrollIntoView();", applyElement);
		applyElement.click();
		driver.findElement(updateOK).click();
 
        //Choose 'Actions' -> New Payment -> Suspense payment 
		WebElement actions = driver.findElement(By.id("DesktopGroup:DesktopMenuActions-btnInnerEl"));
		actions.click();
		
		WebElement newPayment = driver.findElement(By.id("DesktopGroup:DesktopMenuActions:DesktopMenuActions_NewPayment-textEl"));
		newPayment.click();
		
		WebElement suspensePayment = driver.findElement(By.id("DesktopGroup:DesktopMenuActions:DesktopMenuActions_NewPayment:DesktopMenuActions_NewSuspensePayment-textEl"));
		suspensePayment.click();
		
		// all madatory fields and press 'Update'
		writeTextBoxByKeys(creationDateBox, creationDateText);
		writeTextBoxByKeys(ammount, ammountText);
		writeTextBoxByKeys(paymentInstrument, paymentInstrumentText);
		driver.findElement(updateOK).click();
		// the newly-created Suspense payment, mark the checkbox on the very, left and press 'Reverse', OK. 
        By checkbox = By.xpath("//a[contains(text(), 'Check')]/../../..//img[contains(@class,'x-grid-checkcolumn ')]");
        driver.findElement(checkbox).click();
        
        By reverse = By.xpath("//span[contains(@id, 'reverse')]");
		driver.findElement(reverse).click();
		driver.findElement(updateOK).click();
	}
	
	public static void writeTextBoxByKeys(By locator, String excelText)
			throws InterruptedException {
		try {
			Thread.sleep(1000);
			driver.findElement(locator).sendKeys(Keys.CONTROL + "a");
			driver.findElement(locator).sendKeys(Keys.BACK_SPACE);
			driver.findElement(locator).sendKeys(excelText);
			driver.findElement(locator).sendKeys(Keys.ENTER);
			Thread.sleep(2000);
			driver.findElement(locator).sendKeys(Keys.TAB);
			Thread.sleep(2000);

		} catch (Exception e) {
			System.out.println("Not found: " + locator);
		}
	}
}
